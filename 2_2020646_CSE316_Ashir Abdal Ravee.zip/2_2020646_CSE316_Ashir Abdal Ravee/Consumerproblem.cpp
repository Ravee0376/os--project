#include <iostream>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
using namespace std;

#define MAX_BUFFER 5

typedef int buffer_type;
buffer_type circular_buffer[MAX_BUFFER];
int insert_position = 0, remove_position = 0;

pthread_mutex_t buffer_mutex;
sem_t slots_available, items_available;

void SetupBuffer() {
    pthread_mutex_init(&buffer_mutex, nullptr);
    sem_init(&slots_available, 0, MAX_BUFFER);
    sem_init(&items_available, 0, 0);
}

int AddToBuffer(buffer_type item) {
    sem_wait(&slots_available);
    pthread_mutex_lock(&buffer_mutex);

    circular_buffer[insert_position] = item;
    insert_position = (insert_position + 1) % MAX_BUFFER;

    pthread_mutex_unlock(&buffer_mutex);
    sem_post(&items_available);
    return 0; // Success
}

int TakeFromBuffer(buffer_type *item) {
    sem_wait(&items_available);
    pthread_mutex_lock(&buffer_mutex);

    *item = circular_buffer[remove_position];
    remove_position = (remove_position + 1) % MAX_BUFFER;

    pthread_mutex_unlock(&buffer_mutex);
    sem_post(&slots_available);
    return 0; // Success
}

void *Producer(void *param) {
    buffer_type item;
    while (true) {
        usleep(rand() % 1000000);
        item = rand();

        if (AddToBuffer(item) != 0)
            cerr << "Producer encountered an error.\n";
        else
            cout << "Producer created: " << item << endl;
    }
}

void *Consumer(void *param) {
    buffer_type item;
    while (true) {
        usleep(rand() % 1000000);

        if (TakeFromBuffer(&item) != 0)
            cerr << "Consumer encountered an error.\n";
        else
            cout << "Consumer received: " << item << endl;
    }
}

int main(int arg_count, char *arg_vector[]) {
    if (arg_count != 4) {
        cerr << "Usage: " << arg_vector[0] << " <duration> <producer_count> <consumer_count>\n";
        return 1;
    }

    int duration = atoi(arg_vector[1]);
    int producer_count = atoi(arg_vector[2]);
    int consumer_count = atoi(arg_vector[3]);

    SetupBuffer();

    pthread_t producer_threads[producer_count];
    for (int i = 0; i < producer_count; ++i)
        pthread_create(&producer_threads[i], nullptr, Producer, nullptr);

    pthread_t consumer_threads[consumer_count];
    for (int i = 0; i < consumer_count; ++i)
        pthread_create(&consumer_threads[i], nullptr, Consumer, nullptr);

    sleep(duration);

    for (int i = 0; i < producer_count; ++i)
        pthread_cancel(producer_threads[i]);

    for (int i = 0; i < consumer_count; ++i)
        pthread_cancel(consumer_threads[i]);

    sem_destroy(&slots_available);
    sem_destroy(&items_available);
    pthread_mutex_destroy(&buffer_mutex);

    return 0;
}
