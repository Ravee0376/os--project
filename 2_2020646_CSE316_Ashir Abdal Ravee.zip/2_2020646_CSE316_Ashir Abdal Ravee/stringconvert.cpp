#include <iostream>
#include <thread>
#include <mutex>
#include <vector>
#include <string>
#include <cctype>

using namespace std;

mutex textMutex;

char ChangeCharacterCase(char character) {
    return islower(character) ? toupper(character) : tolower(character);
}

void ConvertCharacter(string& text, int position) {
    lock_guard<mutex> lock(textMutex);
    char originalChar = text[position];
    char convertedChar = ChangeCharacterCase(originalChar);
    text[position] = convertedChar;
    cout << "Thread " << this_thread::get_id() << " converted '" << originalChar << "' to '" << convertedChar << "'" << endl;
}

int main(int argc, char* argv[]) {
    if (argc < 2) {
        cerr << "Usage: " << argv[0] << " <text_to_convert>" << endl;
        return 1;
    }

    string textToConvert(argv[1]);
    vector<thread> threads;

    for (size_t i = 0; i < textToConvert.length(); ++i) {
        threads.emplace_back(ConvertCharacter, ref(textToConvert), i);
    }

    for (auto& t : threads) {
        t.join();
    }

    cout << "Final converted text: " << textToConvert << endl;

    return 0;
}
