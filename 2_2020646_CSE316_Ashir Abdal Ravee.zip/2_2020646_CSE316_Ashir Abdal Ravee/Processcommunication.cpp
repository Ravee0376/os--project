#include <iostream>
#include <unistd.h>
#include <sys/wait.h>
#include <cmath>

using namespace std;

int CalculateTerm(int coefficient, int baseValue, int power) {
    int termResult = 1;
    for (int i = 0; i < power; ++i) {
        termResult *= baseValue;
    }
    return coefficient * termResult;
}

int main(int argc, char *argv[]) {
    if (argc < 3) {
        cerr << "Usage: " << argv[0] << " <value to evaluate at> <coefficients in ascending order>" << endl;
        return 1;
    }

    int evaluationPoint = atoi(argv[1]);
    int coefficientsCount = argc - 2;
    int polynomialSum = 0;

    for (int index = coefficientsCount - 1; index >= 0; --index) {
        int currentCoefficient = atoi(argv[index + 2]);
        int currentPower = index;

        pid_t childPID = fork();

        if (childPID == 0) {
            // Child process
            int termValue = CalculateTerm(currentCoefficient, evaluationPoint, currentPower);
            cout << "Child process " << getpid() << " calculated term: " << termValue << endl;
           
            _exit(termValue >= 0 ? termValue : 256 + termValue);
        } else if (childPID < 0) {
            cerr << "Error creating child process." << endl;
            return 1;
        }
    }

    // Parent process
    for (int i = 0; i < coefficientsCount; ++i) {
        int status;
        wait(&status);
       
        if (WIFEXITED(status)) {
            int termResult = WEXITSTATUS(status);
            cout << "Parent received: " << termResult << endl;
            polynomialSum += (termResult <= 127) ? termResult : termResult - 256;
        }
    }

    cout << "Polynomial evaluation result: " << polynomialSum << endl;

    return 0;
}
