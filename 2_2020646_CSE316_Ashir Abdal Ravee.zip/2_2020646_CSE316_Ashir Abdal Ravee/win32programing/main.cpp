#include <windows.h>
#include <string>

int MessageBoxDisplayCount = 0;
int ReallyModifierCount = 0;

// Function to create the message string
std::string CreateMessage(int reallyCount) {
    std::string message = "Do you ";
    for (int i = 0; i < reallyCount; ++i) {
        message += "really ";
    }
    message += "want to continue?";
    return message;
}

// Entry point for a Windows application
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    while (true) {
        std::string title = "Confirmation " + std::to_string(MessageBoxDisplayCount + 1);
        std::string message = CreateMessage(ReallyModifierCount);

        int userChoice = MessageBox(NULL, message.c_str(), title.c_str(), MB_YESNO | MB_ICONQUESTION);

        if (userChoice == IDNO) {
            break;
        } else {
            MessageBoxDisplayCount++;
            ReallyModifierCount = MessageBoxDisplayCount;
        }
    }

    return 0;
}
